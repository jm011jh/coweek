document.querySelector(".login--checkForm-state").addEventListener("click",function(e,i){
    !this.classList.contains("checked") ? this.classList.add("checked") : this.classList.remove("checked")
})