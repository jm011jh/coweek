$.get("./Header.html", (data)=>{$("#header").prepend(data)})
$.get("./Footer.html", (data)=>{$("#footer").prepend(data)})